import 'package:flutter_staggered_animations/flutter_staggered_animations.dart';
import 'package:flutter/material.dart';
import 'package:logger/logger.dart';
import 'package:dio/dio.dart';
import 'package:http/http.dart' as http;
import 'dart:async';
import 'dart:io';
import 'database.dart';
import 'package:sqflite/sqflite.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:path_provider/path_provider.dart';
import './main.dart';
class InstitutionView extends StatefulWidget {
  final DatabaseHandler databaseHandler;
  final List pathIds;
  InstitutionView({required this.databaseHandler, required this.pathIds}) ;

  @override
  State<StatefulWidget> createState() => InstitutionViewState();
}
class InstitutionViewState extends State<InstitutionView> {
  final logger = Logger();
  Dio dio = Dio();
  List<dynamic> dataToDisplay = [];
  InstitutionDataController intituData = InstitutionDataController();
  late Future listData;
  late dynamic data;
  @override
  void initState(){
    super.initState();
    listData = intituData.getInstitution(widget.databaseHandler);
    
  }
  @override
  void didChangeDependencies(){
    super.didChangeDependencies();
    //imageUrl = (int i) => getVal();//downloadImage(response, data[index]);
  }
  Future<int> getVal(i)async {
    return await i;
  }
  
 
  @override
  Widget build(BuildContext context) => FutureBuilder(
    future: listData,
    builder: (context, snapshot){
      return WillPopScope(
          onWillPop: () async{
            Fluttertoast.showToast(
                          msg: 'goodbye',
                          toastLength: Toast.LENGTH_SHORT,
                          gravity: ToastGravity.BOTTOM,
                          backgroundColor: Colors.black87,
                          textColor: Colors.white);
            return true;
          },
          child: Scaffold(
            body: CustomScrollView(
              slivers: [
                 SliverAppBar(
                  pinned: true,
                  floating: false,
                  expandedHeight: MediaQuery.of(context).size.height * 0.20,
                  backgroundColor: const Color(0xff00B19e),
                  flexibleSpace: const FlexibleSpaceBar(
                    title: Text("Togo", style: TextStyle(color: Colors.white, fontSize: 20.0, fontWeight: FontWeight.bold),),
                    background: Opacity(
                      opacity: 0.2,
                      child: Image(
                        fit: BoxFit.cover,
                        image: AssetImage("assets/logos/togo.png"),
                      ),
                    ),
                    
                  ),
                ),
                snapshot.hasData? buildPage(snapshot.data) : Helpers.buildWaiting(),
              ],
            ),
          )
        );
    }
  );



  buildPage(response){
    data = response;
    List institutions = response["institutions"];
    int count = institutions.length;
    return AnimationLimiter(
          child: SliverGrid(
            gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: 2,
            ),
            delegate: SliverChildBuilderDelegate((BuildContext context, int index) {
                return buildElement(institutions[index], index);
            },
            childCount: count,
            ),
          )
        ); 
  }
  buildElement(element, index){
    return AnimationConfiguration.staggeredList(
      position: index,
      duration: const Duration(milliseconds: 375),
      child: SlideAnimation(
        horizontalOffset: 100.0,
        child: FadeInAnimation(
            child: Padding(
                padding: const EdgeInsets.only(top:5),
                child: Card(
                  clipBehavior: Clip.antiAlias,
                  elevation: 16, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                  child: InkWell(
                    onTap: (){},
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Expanded(flex: 50, child: Stack(
                          alignment: Alignment.bottomLeft,//downloadImage(response, data[index])
                          children: <Widget>[
                            FutureBuilder(
                              future: downloadImage(element),
                              builder: (context, snapshot) {
                                  if (snapshot.hasData) {
                                      return  snapshot.data.toString() != "default"? 
                                      Image.file(File(snapshot.data.toString())):
                                      Ink.image( image: const AssetImage("assets/logos/default_logo.png"),fit: BoxFit.fitWidth,);
                                    } else if (snapshot.hasError) {
                                      return Ink.image( image: const AssetImage("assets/logos/default_logo.png"),fit: BoxFit.fitWidth,);
                                    }
                                
                                return Ink.image( image: const AssetImage("assets/logos/default_logo.png"),fit: BoxFit.fitWidth,);
                              },
                            ),
                            const Center(child: Text("", style: TextStyle(color: Colors.black54, fontWeight: FontWeight.bold),),),
                          ],//widget.institutionList[index].name
                        ),),
                        Expanded(flex: 20, child: Padding(
                          padding: const EdgeInsets.only(left: 30, top:5),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: <Widget>[
                            Text(element.name, style: const TextStyle(color: Colors.black54, fontWeight: FontWeight.bold, fontSize: 25),)
                            ],),)),
                        Expanded(flex: 30, child: Padding(
                          padding: const EdgeInsets.only(left: 5, right:5),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: <Widget>[
                              Text(element.fullName, style: const TextStyle(color: Colors.black54),)
                            ],),))],
                    ),
                  ),
                ))
        ),
      ),
    );
  }
  Widget listItem(Color color, String title) => Container(
    height: 100.0,
    color: color,
    child: Center(
      child: Text(
        "$title",
        textAlign: TextAlign.center,
        style: const TextStyle(
            color: Colors.white,
            fontSize: 10.0,
            fontWeight: FontWeight.bold,),
      ),
    ),
  );
  //Download tutorial: https://youtu.be/Gru7swUQqsg
  Future<String> downloadImage(element) async {
    final directory = await getApplicationDocumentsDirectory();
    String savePath = directory.path;
    if (element.fileName != 'null'){
      if(data["insert"].contains(element.id) || data["update"].contains(element.id)){
        
      String urlPath = "http://enovsky.com/campusvirtuel/public/logos/"+element.fileName;
      var response = await http.get(Uri.parse(urlPath));
      await Directory(savePath).create(recursive: true);
      File file = File(savePath+"/"+element.fileName);
      file.writeAsBytesSync(response.bodyBytes);
          return directory.path+"/"+element.fileName; 
      }else{
        return directory.path+"/"+element.fileName; }
    }else {
      return "default"; }
  }
  
}


class Institution {
  final String id;
  final String name;
  final String fullName;
  final String type;
  final String fileName;
  final String updatedDate;

  Institution({required this.id, required this.name, required this.fullName, required this.type, required this.fileName, required this.updatedDate });
  // Convert object into a Map object
  
  Map<String, dynamic> toMap() {
		var map = Map<String, dynamic>();
		map['id'] = id;
		map['updated_date'] = updatedDate;
		return map;
	}
  factory Institution.fromJson(Map<String, dynamic> element) {
    return Institution(
        id: element['id'],
        name: element['name'],
        fullName: element['full_name'],
        type: element['type'],
        fileName: element['file_name'],
        updatedDate: element['updated_date']
    );
  }
}
/*  */
class InstitutionDataController {

  void insertInstitution(databaseHandler, params) async{
    Database database = await databaseHandler.init();
    await database.rawInsert('''INSERT INTO institution (id, name, full_name, type, file_name, created_date, updated_date) VALUES (?,?,?,?,?,?,?)''', params);
  }
  void updateInstitution(databaseHandler, params) async{
    Database database = await databaseHandler.init();
    await database.rawUpdate('''UPDATE institution SET name = ?, full_name = ?, type = ?, file_name = ?, updated_date = ? WHERE id = ?''', params);
    }
  void deleteInstitution(databaseHandler, param) async{
    Database database = await databaseHandler.init();
    await database.rawDelete('''DELETE FROM institution WHERE id = ?''', [param]);
    }
  Future<List<Institution>> selectInstitution(databaseHandler) async{
    Database database = await databaseHandler.init();
    List<Institution> institutions = [];
    var response = await database.rawQuery('SELECT * FROM institution');
    for (int i = 0; i < response.length; i++) {
      institutions.add(Institution.fromJson(response[i]));
		}
    return institutions;
  }
  Future<Map> getRemoteInstitution(databaseHandler, localInfos) async{
    String url = 'http://enovsky.com/campusvirtuel/request_native';
    var data = {
      'parents':  [],
      'table': "institution",
      'local_infos': localInfos
    };
    try{
      Dio dio = Dio();
      Response response = await dio.post(url, data: data, options: Options(contentType: Headers.formUrlEncodedContentType));
      if (response.statusCode == 200 || response.statusCode == 201) {
        //Insert new data 
        List insertData = response.data['insert'];
        List newInsert = [];
        for (int i = 0; i < insertData.length; i++) {
          newInsert.add(insertData[i]['id']);
          List params = [insertData[i]['id'], insertData[i]['name'],insertData[i]['full_name'],insertData[i]['type'],insertData[i]['file_name'],'null',insertData[i]['updated_date']];
          insertInstitution(databaseHandler, params);
        }
        //Update old local data
        List updateData = response.data['update'];
        List newUpdate = [];
        for (int i = 0; i < updateData.length; i++) {
          newUpdate.add(updateData[i]['id']);
          List params = [updateData[i]['name'],updateData[i]['full_name'],updateData[i]['type'],updateData[i]['file_name'],updateData[i]['updated_date'],updateData[i]['id']];
          updateInstitution(databaseHandler, params);
        }
        //Delete data that are not present in remote
        List deleteData = response.data['delete'];
        for (int i = 0; i < deleteData.length; i++) {
          deleteInstitution(databaseHandler, deleteData[i]);
        }
        return {"insert": newInsert, "update": newUpdate};
      } else {
        throw Exception('Failed to creat');
      }
    } catch (error){
      return {};
    }
  }
  Future<Map> getInstitution(databaseHandler) async{
    
    List<Map<String, dynamic>> localInfos = [];
    List<Institution> institutionLocal = await selectInstitution(databaseHandler);
    
    for(Institution institution in institutionLocal){
      localInfos.add(institution.toMap());
    }
    Map response = await getRemoteInstitution(databaseHandler, localInfos);
    //saveFiles(modifyElements);
    List<Institution>  institutions = await selectInstitution(databaseHandler);
    response["institutions"] = institutions;
    return response;
  }

  
}
